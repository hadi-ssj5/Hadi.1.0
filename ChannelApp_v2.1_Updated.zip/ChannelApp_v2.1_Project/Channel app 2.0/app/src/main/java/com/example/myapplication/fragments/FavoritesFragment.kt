package com.example.myapplication.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.*
import com.example.myapplication.model.Channel
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.floatingactionbutton.FloatingActionButton

class FavoritesFragment : Fragment() {

    private val repository = ChannelRepository()
    private lateinit var rvFavorites: RecyclerView
    private lateinit var tvEmpty: TextView
    private lateinit var favAdapter: ChannelAdapter
    private var favChannels = mutableListOf<Channel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_favorites, container, false)
        rvFavorites = view.findViewById(R.id.rvFavorites)
        tvEmpty = view.findViewById(R.id.tvNoFavorites)

        loadFavorites()

        val btnAdd = view.findViewById<FloatingActionButton>(R.id.btnAddToFavorites)
        btnAdd.setOnClickListener {
            showAddChannelsSheet()
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }

    private fun loadFavorites() {
        val prefs = requireActivity().getSharedPreferences("Favorites", android.content.Context.MODE_PRIVATE)
        val favNames = prefs.getStringSet("fav_list", emptySet()) ?: emptySet()
        val allChannels = repository.getLocalChannels(requireContext())
        favChannels = allChannels.filter { favNames.contains(it.name) }.distinctBy { it.name }.toMutableList()

        if (favChannels.isEmpty()) {
            tvEmpty.visibility = View.VISIBLE
            rvFavorites.visibility = View.GONE
        } else {
            tvEmpty.visibility = View.GONE
            rvFavorites.visibility = View.VISIBLE
            rvFavorites.layoutManager = GridLayoutManager(requireContext(), 2)
            favAdapter = ChannelAdapter(favChannels) { channel ->
                val p = requireActivity().getSharedPreferences("Favorites", android.content.Context.MODE_PRIVATE)
                val favorites = p.getStringSet("fav_list", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
                favorites.remove(channel.name)
                p.edit().putStringSet("fav_list", favorites).apply()
                loadFavorites()
            }
            rvFavorites.adapter = favAdapter
        }
    }

    private fun showAddChannelsSheet() {
        val dialog = BottomSheetDialog(requireContext())
        val sheetView = LayoutInflater.from(requireContext()).inflate(R.layout.sheet_add_favorites, null)
        dialog.setContentView(sheetView)
        dialog.behavior.peekHeight = 600

        val searchEdit = sheetView.findViewById<EditText>(R.id.etFavSearch)
        val btnFilter = sheetView.findViewById<ImageButton>(R.id.btnFavFilter)
        val rvChannels = sheetView.findViewById<RecyclerView>(R.id.rvFavAllChannels)

        val allChannels = repository.getLocalChannels(requireContext()).distinctBy { it.name }
        var displayedChannels = allChannels.toMutableList()
        var activeFilters = mapOf<String, List<String>>()

        rvChannels.layoutManager = LinearLayoutManager(requireContext())

        val sheetAdapter = AddFavChannelAdapter(displayedChannels) { channel ->
            val prefs = requireActivity().getSharedPreferences("Favorites", android.content.Context.MODE_PRIVATE)
            val favorites = prefs.getStringSet("fav_list", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
            if (!favorites.contains(channel.name)) {
                favorites.add(channel.name)
                prefs.edit().putStringSet("fav_list", favorites).apply()
            }
        }
        rvChannels.adapter = sheetAdapter

        // Search without keyboard jump - use post to avoid layout issues
        searchEdit.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val query = s?.toString() ?: ""
                filterSheetChannels(allChannels, query, activeFilters, sheetAdapter, displayedChannels)
            }
        })

        btnFilter.setOnClickListener {
            FilterDialogFragment { filters ->
                activeFilters = filters
                filterSheetChannels(allChannels, searchEdit.text.toString(), activeFilters, sheetAdapter, displayedChannels)
            }.show(childFragmentManager, "favfilter")
        }

        dialog.show()
    }

    private fun filterSheetChannels(
        all: List<Channel>,
        query: String,
        filters: Map<String, List<String>>,
        adapter: AddFavChannelAdapter,
        list: MutableList<Channel>
    ) {
        var result = all
        if (query.isNotEmpty()) {
            result = result.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.categoryAr.contains(query, ignoreCase = true) ||
                it.satellite.contains(query, ignoreCase = true)
            }
        }
        filters["satellite"]?.let { sats ->
            if (sats.isNotEmpty()) result = result.filter { ch -> sats.any { ch.satellite.contains(it, ignoreCase = true) } }
        }
        filters["category"]?.let { cats ->
            if (cats.isNotEmpty()) result = result.filter { ch -> cats.any { ch.category.equals(it, ignoreCase = true) || ch.categoryAr.contains(it, ignoreCase = true) } }
        }
        filters["encryption"]?.let { encs ->
            if (encs.isNotEmpty()) result = result.filter { ch ->
                encs.any { enc -> if (enc == "FTA") ch.encryption == "FTA" else ch.encryption.contains("Enc") }
            }
        }
        list.clear()
        list.addAll(result)
        adapter.notifyDataSetChanged()
    }

    // Inner adapter for add-to-favorites sheet
    inner class AddFavChannelAdapter(
        private val channels: MutableList<Channel>,
        private val onAdd: (Channel) -> Unit
    ) : RecyclerView.Adapter<AddFavChannelAdapter.VH>() {

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val tvName: TextView = v.findViewById(R.id.tvAddFavName)
            val tvDetails: TextView = v.findViewById(R.id.tvAddFavDetails)
            val btnAdd: ImageButton = v.findViewById(R.id.btnAddFavItem)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_add_fav_channel, parent, false)
            return VH(v)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val ch = channels[position]
            holder.tvName.text = ch.name
            val encLabel = if (ch.encryption.contains("Enc", true)) " 🔐" else " 📡"
            holder.tvDetails.text = "${ch.satellite.substringBefore(" ")} | ${ch.frequency} ${ch.polarization}$encLabel"

            val prefs = requireActivity().getSharedPreferences("Favorites", android.content.Context.MODE_PRIVATE)
            val isFav = (prefs.getStringSet("fav_list", emptySet()) ?: emptySet()).contains(ch.name)
            holder.btnAdd.setImageResource(
                if (isFav) android.R.drawable.btn_star_big_on else android.R.drawable.ic_input_add
            )

            holder.btnAdd.setOnClickListener {
                onAdd(ch)
                holder.btnAdd.setImageResource(android.R.drawable.btn_star_big_on)
                loadFavorites()
            }

            holder.itemView.setOnClickListener {
                ChannelAdapter.showDetailDialog(requireContext(), ch)
            }
        }

        override fun getItemCount() = channels.size
    }
}
