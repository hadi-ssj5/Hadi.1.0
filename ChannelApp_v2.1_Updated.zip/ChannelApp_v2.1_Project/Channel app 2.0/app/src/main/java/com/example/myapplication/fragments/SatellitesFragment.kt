package com.example.myapplication.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.ChannelRepository
import com.example.myapplication.R
import com.example.myapplication.SatelliteAdapter

class SatellitesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_satellites, container, false)
        val rv = view.findViewById<RecyclerView>(R.id.rvAllSatellites)
        
        val satellites = ChannelRepository().getLocalChannels(requireContext()).map { it.satellite }.distinct()
        rv.layoutManager = GridLayoutManager(requireContext(), 2)
        rv.adapter = SatelliteAdapter(satellites)
        
        return view
    }
}
