package com.example.myapplication

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import coil.load
import coil.request.CachePolicy
import com.example.myapplication.model.Channel

class ChannelAdapter(
    private var channels: List<Channel>,
    private val onFavClick: ((Channel) -> Unit)? = null
) : RecyclerView.Adapter<ChannelAdapter.ChannelViewHolder>() {

    class ChannelViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.channelName)
        val details: TextView = view.findViewById(R.id.channelDetails)
        val logo: ImageView = view.findViewById(R.id.channelLogo)
        val btnAddFav: ImageButton = view.findViewById(R.id.btnAddFav)
        val card: com.google.android.material.card.MaterialCardView = view.findViewById(R.id.channelCard)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChannelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return ChannelViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelViewHolder, position: Int) {
        val channel = channels[position]
        val context = holder.itemView.context

        val colors = listOf("#E64A19","#6A1B9A","#1565C0","#AD1457","#E65100","#2E7D32","#00838F","#6D4C41")
        holder.card.setCardBackgroundColor(Color.parseColor(colors[position % colors.size]))

        holder.name.text = channel.name
        val encLabel = if (channel.encryption.contains("Enc", ignoreCase = true)) " 🔐" else " 📡"
        holder.details.text = "${channel.satellite.substringBefore(" ")} | ${channel.frequency}$encLabel"

        holder.logo.load(channel.imageUrl) {
            crossfade(true)
            placeholder(R.drawable.ic_tv_placeholder)
            error(R.drawable.ic_tv_placeholder)
            memoryCachePolicy(CachePolicy.ENABLED)
        }

        holder.itemView.setOnClickListener {
            showDetailDialog(context, channel)
        }

        val prefs = context.getSharedPreferences("Favorites", Context.MODE_PRIVATE)
        val favs = prefs.getStringSet("fav_list", emptySet()) ?: emptySet()
        val isFav = favs.contains(channel.name)
        holder.btnAddFav.setImageResource(
            if (isFav) android.R.drawable.btn_star_big_on else android.R.drawable.btn_star_big_off
        )

        holder.btnAddFav.setOnClickListener {
            val favorites = prefs.getStringSet("fav_list", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
            if (favorites.contains(channel.name)) {
                favorites.remove(channel.name)
                holder.btnAddFav.setImageResource(android.R.drawable.btn_star_big_off)
            } else {
                favorites.add(channel.name)
                holder.btnAddFav.setImageResource(android.R.drawable.btn_star_big_on)
                onFavClick?.invoke(channel)
            }
            prefs.edit().putStringSet("fav_list", favorites).apply()
        }
    }

    override fun getItemCount() = channels.size

    fun updateData(newChannels: List<Channel>) {
        channels = newChannels
        notifyDataSetChanged()
    }

    companion object {
        fun showDetailDialog(context: Context, channel: Channel) {
            val dialog = Dialog(context)
            dialog.setContentView(R.layout.dialog_channel_detail)
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

            val ivLogo = dialog.findViewById<ImageView>(R.id.detailChannelImg)
            val tvName = dialog.findViewById<TextView>(R.id.detailChannelName)
            val tvShortCat = dialog.findViewById<TextView>(R.id.detailShortCat)
            val pager = dialog.findViewById<ViewPager2>(R.id.satellitePager)
            val dotsContainer = dialog.findViewById<LinearLayout>(R.id.dotsContainer)
            val btnClose = dialog.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnCloseDetail)

            tvName.text = channel.name
            val repo = ChannelRepository()
            val catAr = repo.mapEnToAr(channel.category)
            tvShortCat.text = "$catAr · ${channel.category}"

            ivLogo.load(channel.imageUrl) {
                crossfade(true)
                placeholder(R.drawable.ic_tv_placeholder)
                error(R.drawable.ic_tv_placeholder)
                memoryCachePolicy(CachePolicy.ENABLED)
            }

            // Get all frequencies for this channel across all satellites
            val allFreqs = repo.getLocalChannels(context)
                .filter { it.name.equals(channel.name, ignoreCase = true) }
                .distinctBy { it.satellite + it.frequency }

            val satelliteList = if (allFreqs.isEmpty()) listOf(channel) else allFreqs

            val adapter = SatellitePagerAdapter(satelliteList)
            pager.adapter = adapter
            pager.offscreenPageLimit = 1

            // Disable over-scroll
            (pager.getChildAt(0) as? RecyclerView)?.apply {
                overScrollMode = RecyclerView.OVER_SCROLL_NEVER
            }

            // Build dot indicators
            buildDotIndicators(context, dotsContainer, satelliteList.size)
            updateDots(dotsContainer, 0)

            pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    updateDots(dotsContainer, position)
                }
            })

            btnClose.setOnClickListener { dialog.dismiss() }
            dialog.show()
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }

        private fun buildDotIndicators(context: Context, container: LinearLayout, count: Int) {
            container.removeAllViews()
            if (count <= 1) return
            for (i in 0 until count) {
                val dot = View(context)
                val size = 10
                val params = LinearLayout.LayoutParams(size.dpToPx(context), size.dpToPx(context))
                params.marginStart = 6
                params.marginEnd = 6
                dot.layoutParams = params
                dot.setBackgroundResource(R.drawable.dot_inactive)
                container.addView(dot)
            }
        }

        private fun updateDots(container: LinearLayout, activeIndex: Int) {
            for (i in 0 until container.childCount) {
                val dot = container.getChildAt(i)
                dot.setBackgroundResource(
                    if (i == activeIndex) R.drawable.dot_active else R.drawable.dot_inactive
                )
            }
        }

        private fun Int.dpToPx(context: Context): Int =
            (this * context.resources.displayMetrics.density).toInt()
    }
}
