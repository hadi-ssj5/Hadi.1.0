package com.example.myapplication.fragments

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.example.myapplication.ChannelRepository
import com.example.myapplication.R
import com.example.myapplication.model.Channel
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class SettingsFragment : Fragment() {

    private var selectedReceiverType = "neomax"
    private lateinit var tvSelectedCount: TextView
    private lateinit var tvBackupInfo: TextView

    private val createFileLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
            uri?.let { saveBackupToUri(it) }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        // Language settings
        val radioGroup = view.findViewById<RadioGroup>(R.id.radioGroupLang)
        val prefs = requireActivity().getSharedPreferences("Settings", Context.MODE_PRIVATE)
        val currentLang = prefs.getString("lang", "ar")
        if (currentLang == "ar") view.findViewById<RadioButton>(R.id.radioAr).isChecked = true
        else view.findViewById<RadioButton>(R.id.radioEn).isChecked = true

        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            val lang = if (checkedId == R.id.radioAr) "ar" else "en"
            if (prefs.getString("lang", "ar") != lang) {
                prefs.edit().putString("lang", lang).apply()
                requireActivity().recreate()
            }
        }

        // Backup section
        tvSelectedCount = view.findViewById(R.id.tvSelectedChannelsCount)
        tvBackupInfo = view.findViewById(R.id.tvBackupInfo)

        val receiverGroup = view.findViewById<RadioGroup>(R.id.radioGroupReceiver)
        receiverGroup.setOnCheckedChangeListener { _, checkedId ->
            selectedReceiverType = when (checkedId) {
                R.id.radioNeomax -> "neomax"
                R.id.radioHumax -> "humax"
                R.id.radioStarGold -> "stargold"
                else -> "neomax"
            }
            updateBackupInfo()
        }

        updateFavCount()
        updateBackupInfo()

        view.findViewById<Button>(R.id.btnExportBackup).setOnClickListener {
            exportBackup()
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        updateFavCount()
    }

    private fun updateFavCount() {
        val prefs = requireActivity().getSharedPreferences("Favorites", Context.MODE_PRIVATE)
        val favNames = prefs.getStringSet("fav_list", emptySet()) ?: emptySet()
        tvSelectedCount.text = if (favNames.isEmpty())
            "لا توجد قنوات في المفضلة"
        else
            "✅ ${favNames.size} قناة في المفضلة جاهزة للتصدير"
    }

    private fun updateBackupInfo() {
        tvBackupInfo.text = when (selectedReceiverType) {
            "neomax"   -> "📁 سيتم حفظ ملف .nvm (Neomax Channel List)"
            "humax"    -> "📁 سيتم حفظ ملف .zip يحتوي على APP_CHANNELDB بتنسيق Humax الثنائي - قابل للاستيراد عبر USB"
            "stargold" -> "📁 سيتم حفظ ملف .sgf (StarGold Channel File)"
            else       -> ""
        }
    }

    private fun exportBackup() {
        val prefs = requireActivity().getSharedPreferences("Favorites", Context.MODE_PRIVATE)
        val favNames = prefs.getStringSet("fav_list", emptySet()) ?: emptySet()
        if (favNames.isEmpty()) {
            Toast.makeText(requireContext(), "❌ المفضلة فارغة، أضف قنوات أولاً", Toast.LENGTH_SHORT).show()
            return
        }

        val (ext, mime) = when (selectedReceiverType) {
            "neomax"   -> Pair("nvm", "*/*")
            "humax"    -> Pair("zip", "application/zip")
            "stargold" -> Pair("sgf", "*/*")
            else       -> Pair("txt", "text/plain")
        }

        val fileName = "channels_backup_${selectedReceiverType}.$ext"
        createFileLauncher.launch(fileName)
    }

    private fun saveBackupToUri(uri: Uri) {
        try {
            val prefs = requireActivity().getSharedPreferences("Favorites", Context.MODE_PRIVATE)
            val favNames = prefs.getStringSet("fav_list", emptySet()) ?: emptySet()
            val repo = ChannelRepository()
            val allChannels = repo.getLocalChannels(requireContext())
            val favChannels = allChannels.filter { favNames.contains(it.name) }.distinctBy { it.name }

            val bytes = when (selectedReceiverType) {
                "neomax"   -> buildNeomaxFormat(favChannels).toByteArray(Charsets.UTF_8)
                "humax"    -> buildHumaxZipBackup(favChannels)
                "stargold" -> buildStarGoldFormat(favChannels).toByteArray(Charsets.UTF_8)
                else       -> buildNeomaxFormat(favChannels).toByteArray(Charsets.UTF_8)
            }

            requireContext().contentResolver.openOutputStream(uri)?.use { os ->
                os.write(bytes)
            }

            Toast.makeText(requireContext(), "✅ تم حفظ ملف النسخة الاحتياطية بنجاح", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "❌ فشل الحفظ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ─────────────────────────────────────────────────────────────────
    // HUMAX F1-mini Binary Format
    // Generates a ZIP containing the 3 files Humax expects on a USB stick:
    //   Humax F1-mini +ME/APP_ANTINFO    (200 bytes - satellite config)
    //   Humax F1-mini +ME/APP_CHANNELDB  (N × 200 bytes - channel records)
    //   Humax F1-mini +ME/APP_SETUPDB    (fixed header, 2075 bytes)
    // ─────────────────────────────────────────────────────────────────
    private fun buildHumaxZipBackup(channels: List<Channel>): ByteArray {
        val dir = "Humax F1-mini +ME/"

        // Collect unique satellites (for APP_ANTINFO)
        val satellites = channels.map { it.satellite }.distinct()

        val antInfoBytes  = buildHumaxAntInfo(satellites)
        val channelDbBytes = buildHumaxChannelDb(channels, satellites)
        val setupDbBytes  = buildHumaxSetupDb()

        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            // Directory entry
            zos.putNextEntry(ZipEntry(dir))
            zos.closeEntry()

            // APP_ANTINFO
            zos.putNextEntry(ZipEntry("${dir}APP_ANTINFO"))
            zos.write(antInfoBytes)
            zos.closeEntry()

            // APP_CHANNELDB
            zos.putNextEntry(ZipEntry("${dir}APP_CHANNELDB"))
            zos.write(channelDbBytes)
            zos.closeEntry()

            // APP_SETUPDB
            zos.putNextEntry(ZipEntry("${dir}APP_SETUPDB"))
            zos.write(setupDbBytes)
            zos.closeEntry()
        }
        return baos.toByteArray()
    }

    /**
     * APP_ANTINFO: up to 8 satellite entries × 25 bytes each = 200 bytes total.
     * Each satellite entry:
     *   Offset 0  : SatIndex (1 byte)
     *   Offset 1  : Orbital position × 10 (2 bytes LE, e.g. 70 for 7.0°W)
     *   Offset 3  : Direction (1 byte: 0=West, 1=East)
     *   Offset 4  : Name (20 bytes, ASCII null-padded)
     *   Offset 24 : Reserved (1 byte, 0xFF)
     */
    private fun buildHumaxAntInfo(satellites: List<String>): ByteArray {
        val buf = ByteBuffer.allocate(200).order(ByteOrder.LITTLE_ENDIAN)
        buf.put(0xFF.toByte()) // signature byte
        buf.put(satellites.size.toByte())
        buf.put(ByteArray(6)) // reserved

        satellites.take(8).forEachIndexed { idx, satName ->
            val (pos, dir) = parseSatPosition(satName)
            buf.put(idx.toByte())           // sat index
            buf.putShort(pos.toShort())     // position × 10
            buf.put(dir.toByte())           // 0=W, 1=E
            val nameBytes = satName.toByteArray(Charsets.UTF_8).copyOf(20)
            buf.put(nameBytes)              // 20 bytes name
            buf.put(0xFF.toByte())          // end marker
        }
        // Pad remaining
        val remaining = 200 - buf.position()
        if (remaining > 0) buf.put(ByteArray(remaining))
        return buf.array()
    }

    /** Parse "Nilesat 7.0°W" → (70, 0)  or "Hotbird 13.0°E" → (130, 1) */
    private fun parseSatPosition(satName: String): Pair<Int, Int> {
        val regex = Regex("(\\d+\\.?\\d*)°([WE])")
        val match = regex.find(satName)
        return if (match != null) {
            val pos = (match.groupValues[1].toFloatOrNull() ?: 0f) * 10
            val dir = if (match.groupValues[2] == "E") 1 else 0
            Pair(pos.toInt(), dir)
        } else Pair(0, 0)
    }

    /**
     * APP_CHANNELDB: 8-byte header + N × 200-byte channel records.
     *
     * Header (8 bytes):
     *   Bytes 0-1: Magic 0x4855 ("HU")
     *   Bytes 2-3: Version 0x0100
     *   Bytes 4-5: Channel count (LE)
     *   Bytes 6-7: Reserved
     *
     * Channel record (200 bytes):
     *   Offset   0: Service name – UTF-16LE, 64 bytes (32 chars), null-padded
     *   Offset  64: Frequency – 4 bytes LE, in kHz (e.g. 10815000 for 10815 MHz)
     *   Offset  68: Symbol rate – 4 bytes LE, in symbols/s (e.g. 27500000)
     *   Offset  72: Polarization – 1 byte (0=H, 1=V)
     *   Offset  73: FEC inner – 1 byte (0=Auto)
     *   Offset  74: Service type – 1 byte (1=TV, 2=Radio)
     *   Offset  75: Scrambled – 1 byte (0=FTA, 1=Enc)
     *   Offset  76: Sat index – 2 bytes LE
     *   Offset  78: Service ID – 2 bytes LE
     *   Offset  80: PMT PID – 2 bytes LE
     *   Offset  82: PCR PID – 2 bytes LE
     *   Offset  84: Video PID – 2 bytes LE
     *   Offset  86: Audio PID – 2 bytes LE
     *   Offset  88–199: reserved/padding (zeros)
     */
    private fun buildHumaxChannelDb(channels: List<Channel>, satellites: List<String>): ByteArray {
        val recordSize = 200
        val headerSize = 8
        val totalSize  = headerSize + channels.size * recordSize

        val buf = ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN)

        // Header
        buf.put('H'.code.toByte())
        buf.put('U'.code.toByte())
        buf.putShort(0x0100)
        buf.putShort(channels.size.toShort())
        buf.putShort(0)

        channels.forEachIndexed { idx, ch ->
            val recordStart = buf.position()

            // Service name: UTF-16LE, max 32 chars (64 bytes)
            val nameUtf16 = ch.name.toByteArray(Charsets.UTF_16LE)
            val namePad   = nameUtf16.copyOf(64)
            buf.put(namePad)

            // Frequency in kHz: "10815" → 10815000
            val freqKhz = (ch.frequency.toLongOrNull() ?: 0L) * 1000L
            buf.putInt(freqKhz.toInt())

            // Symbol rate in sym/s: "27500" → 27500000
            val srSym = (ch.symbolRate.toLongOrNull() ?: 0L) * 1000L
            buf.putInt(srSym.toInt())

            // Polarization: H=0, V=1
            buf.put(if (ch.polarization.equals("H", true)) 0.toByte() else 1.toByte())

            // FEC inner (Auto=0)
            buf.put(0)

            // Service type (1=TV)
            buf.put(1)

            // Scrambled
            buf.put(if (ch.encryption.contains("Enc", true)) 1.toByte() else 0.toByte())

            // Sat index
            val satIdx = satellites.indexOf(ch.satellite).coerceAtLeast(0)
            buf.putShort(satIdx.toShort())

            // Service ID, PMT, PCR, Video, Audio PIDs (synthetic but valid)
            val sid  = (idx + 1) and 0xFFFF
            buf.putShort(sid.toShort())
            buf.putShort((0x0100 + idx).toShort())
            buf.putShort((0x0100 + idx).toShort())
            buf.putShort((0x0200 + idx).toShort())
            buf.putShort((0x0300 + idx).toShort())

            // Pad to 200 bytes
            val written  = buf.position() - recordStart
            val padding  = recordSize - written
            if (padding > 0) buf.put(ByteArray(padding))
        }

        return buf.array()
    }

    /**
     * APP_SETUPDB: minimal 2075-byte setup block.
     * Humax won't reject a backup that has a valid-length SETUPDB.
     */
    private fun buildHumaxSetupDb(): ByteArray {
        val buf = ByteBuffer.allocate(2075).order(ByteOrder.LITTLE_ENDIAN)
        buf.put('H'.code.toByte())
        buf.put('X'.code.toByte())
        buf.put('S'.code.toByte())
        buf.put('D'.code.toByte())
        buf.putShort(0x0100)  // version
        buf.putShort(2075)    // total size
        // rest is zeros (valid defaults for Humax)
        return buf.array()
    }

    // ─────────────────────────────────────────────────────────────────
    // Neomax NVM format
    // ─────────────────────────────────────────────────────────────────
    private fun buildNeomaxFormat(channels: List<Channel>): String {
        val sb = StringBuilder()
        sb.appendLine("[NVM_CHANNEL_LIST]")
        sb.appendLine("Version=1.0")
        sb.appendLine("ReceiverType=Neomax")
        sb.appendLine("ChannelCount=${channels.size}")
        sb.appendLine("")
        channels.forEachIndexed { idx, ch ->
            sb.appendLine("[CH_${idx + 1}]")
            sb.appendLine("Name=${ch.name}")
            sb.appendLine("Frequency=${ch.frequency}")
            sb.appendLine("Polarization=${ch.polarization}")
            sb.appendLine("SymbolRate=${ch.symbolRate}")
            sb.appendLine("Satellite=${ch.satellite}")
            sb.appendLine("Encryption=${ch.encryption}")
            sb.appendLine("Category=${ch.categoryAr}")
            sb.appendLine("")
        }
        return sb.toString()
    }

    // ─────────────────────────────────────────────────────────────────
    // StarGold SGF format
    // ─────────────────────────────────────────────────────────────────
    private fun buildStarGoldFormat(channels: List<Channel>): String {
        val sb = StringBuilder()
        sb.appendLine("[StarGold_Channel_File]")
        sb.appendLine("FileVersion=2")
        sb.appendLine("TotalChannels=${channels.size}")
        sb.appendLine("")
        channels.forEachIndexed { idx, ch ->
            val polNum = if (ch.polarization == "H") "0" else "1"
            sb.appendLine("Channel${idx + 1}Name=${ch.name}")
            sb.appendLine("Channel${idx + 1}Freq=${ch.frequency}")
            sb.appendLine("Channel${idx + 1}Pol=$polNum")
            sb.appendLine("Channel${idx + 1}SR=${ch.symbolRate}")
            sb.appendLine("Channel${idx + 1}Sat=${ch.satellite}")
            sb.appendLine("Channel${idx + 1}FTA=${if (ch.encryption == "FTA") "1" else "0"}")
            sb.appendLine("")
        }
        return sb.toString()
    }
}
