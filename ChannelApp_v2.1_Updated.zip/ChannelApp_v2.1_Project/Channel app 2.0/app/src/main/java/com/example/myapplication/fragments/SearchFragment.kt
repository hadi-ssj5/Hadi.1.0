package com.example.myapplication.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.ImageButton
import android.widget.SearchView
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.*
import com.example.myapplication.model.Channel

class SearchFragment : Fragment() {

    private lateinit var searchView: SearchView
    private lateinit var rvResults: RecyclerView
    private lateinit var rvCategories: RecyclerView
    private val repository = ChannelRepository()
    private var allChannels = listOf<Channel>()
    private lateinit var adapter: ChannelAdapter
    private var activeFilters = mapOf<String, List<String>>()
    private var isKeyboardVisible = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_search, container, false)

        searchView = view.findViewById(R.id.searchViewFull)
        rvResults = view.findViewById(R.id.rvSearchResults)
        rvCategories = view.findViewById(R.id.rvCategoryGrid)
        val btnFilter = view.findViewById<ImageButton>(R.id.btnFilter)

        allChannels = repository.getLocalChannels(requireContext())
        adapter = ChannelAdapter(allChannels) { channel ->
            saveToFavorites(channel)
        }
        rvResults.layoutManager = GridLayoutManager(requireContext(), 3)
        rvResults.adapter = adapter

        fixSearchViewStyle()
        setupSearch()
        setupCategoryGrid()

        btnFilter.setOnClickListener {
            FilterDialogFragment { filters ->
                activeFilters = filters
                applyAdvancedFilters(filters)
            }.show(childFragmentManager, "filter")
        }

        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (rvResults.visibility == View.VISIBLE) {
                    searchView.setQuery("", false)
                    rvResults.visibility = View.GONE
                    rvCategories.visibility = View.VISIBLE
                    searchView.clearFocus()
                    hideKeyboard()
                } else {
                    isEnabled = false
                    requireActivity().onBackPressed()
                }
            }
        })

        val cat = arguments?.getString("category")
        if (cat != null) {
            showFilteredByCategory(cat)
        }

        return view
    }

    override fun onResume() {
        super.onResume()
        // Do NOT open keyboard on resume - only on explicit user tap
        searchView.clearFocus()
        hideKeyboard()
    }

    private fun fixSearchViewStyle() {
        try {
            val searchTextId = searchView.context.resources.getIdentifier("android:id/search_src_text", null, null)
            val searchText = searchView.findViewById<android.widget.EditText>(searchTextId)
            if (searchText != null) {
                searchText.setTextColor(android.graphics.Color.WHITE)
                searchText.setHintTextColor(android.graphics.Color.LTGRAY)
                
                // Toggle keyboard on tap - open on first tap, close on second
                searchText.setOnClickListener {
                    if (isKeyboardVisible) {
                        hideKeyboard()
                        searchText.clearFocus()
                        isKeyboardVisible = false
                    } else {
                        showKeyboard(searchText)
                        isKeyboardVisible = true
                    }
                }
            }
        } catch (e: Exception) {}
    }

    private fun showFilteredByCategory(category: String) {
        rvCategories.visibility = View.GONE
        rvResults.visibility = View.VISIBLE

        if (category.isEmpty()) {
            searchView.setQuery("", false)
            adapter.updateData(allChannels)
            return
        }

        searchView.setQuery(category, false)
        val filtered = allChannels.filter { ch ->
            ch.category.equals(category, ignoreCase = true) ||
            ch.categoryAr.contains(category, ignoreCase = true) ||
            ch.satellite.contains(category, ignoreCase = true) ||
            ch.name.contains(category, ignoreCase = true)
        }
        adapter.updateData(filtered)
    }

    private fun setupSearch() {
        // Start iconified=false but WITHOUT focus so keyboard doesn't appear
        searchView.isIconified = false
        searchView.clearFocus()

        searchView.setOnQueryTextFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                isKeyboardVisible = true
            } else {
                isKeyboardVisible = false
                hideKeyboard()
            }
        }

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                hideKeyboard()
                return false
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText.isNullOrEmpty()) {
                    if (activeFilters.isEmpty() && arguments?.getString("category") == null) {
                        rvCategories.visibility = View.VISIBLE
                        rvResults.visibility = View.GONE
                    } else {
                        adapter.updateData(allChannels)
                    }
                } else {
                    rvCategories.visibility = View.GONE
                    rvResults.visibility = View.VISIBLE
                    val filtered = allChannels.filter {
                        it.name.contains(newText, ignoreCase = true) ||
                        it.category.contains(newText, ignoreCase = true) ||
                        it.categoryAr.contains(newText, ignoreCase = true) ||
                        it.satellite.contains(newText, ignoreCase = true)
                    }
                    adapter.updateData(applyFiltersToList(filtered, activeFilters))
                }
                return true
            }
        })
    }

    private fun applyAdvancedFilters(filters: Map<String, List<String>>) {
        val fragment = ResultsFragment()
        val bundle = Bundle()
        val cats = filters["category"] ?: emptyList()
        val sats = filters["satellite"] ?: emptyList()
        bundle.putString("title", "نتائج التصفية")
        if (cats.isNotEmpty()) bundle.putString("category", cats[0])
        if (sats.isNotEmpty()) bundle.putString("satellite", sats[0])
        bundle.putString("type", "multi")
        fragment.arguments = bundle
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun applyFiltersToList(list: List<Channel>, filters: Map<String, List<String>>): List<Channel> {
        var result = list
        filters["satellite"]?.let { sats ->
            if (sats.isNotEmpty()) result = result.filter { sats.any { s -> it.satellite.contains(s, ignoreCase = true) } }
        }
        filters["category"]?.let { cats ->
            if (cats.isNotEmpty()) result = result.filter { cats.any { c -> it.category.equals(c, ignoreCase = true) || it.categoryAr.contains(c, ignoreCase = true) } }
        }
        filters["encryption"]?.let { encs ->
            if (encs.isNotEmpty()) result = result.filter { ch ->
                encs.any { enc -> if (enc == "FTA") ch.encryption == "FTA" else ch.encryption.contains("Enc") }
            }
        }
        return result
    }

    private fun setupCategoryGrid() {
        val items = listOf(
            "Nile" to "Nilesat 7.0°W",
            "Badr" to "Badr 26.0°E",
            "Hotbird" to "Hotbird 13.0°E",
            "Astra" to "Astra 28.2°E",
            "Yahsat" to "Yahsat 52.5°E",
            "Turksat" to "Turksat 42°E",
            "News" to "أخبار",
            "Sports" to "رياضة",
            "Movies" to "أفلام",
            "Kids" to "كرتون",
            "Religious" to "ديني",
            "General" to "عامة"
        )
        rvCategories.layoutManager = GridLayoutManager(requireContext(), 3)
        rvCategories.adapter = CategorySquareAdapter(items.map { it.first }) { label ->
            val type = if (label.contains("Nile") || label.contains("Badr") || label.contains("Astra") ||
                label.contains("Hotbird") || label.contains("Yah") || label.contains("Turk")) "satellite" else "category"

            val fragment = ResultsFragment()
            val bundle = Bundle()
            bundle.putString("title", label)
            bundle.putString("type", type)
            fragment.arguments = bundle

            searchView.clearFocus()
            hideKeyboard()

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }
    }

    private fun hideKeyboard() {
        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(view?.windowToken, 0)
        isKeyboardVisible = false
    }

    private fun showKeyboard(target: View) {
        target.requestFocus()
        val imm = requireContext().getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(target, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun saveToFavorites(channel: Channel) {
        val prefs = requireActivity().getSharedPreferences("Favorites", Context.MODE_PRIVATE)
        val favorites = prefs.getStringSet("fav_list", mutableSetOf())?.toMutableSet() ?: mutableSetOf()
        favorites.add(channel.name)
        prefs.edit().putStringSet("fav_list", favorites).apply()
    }
}
