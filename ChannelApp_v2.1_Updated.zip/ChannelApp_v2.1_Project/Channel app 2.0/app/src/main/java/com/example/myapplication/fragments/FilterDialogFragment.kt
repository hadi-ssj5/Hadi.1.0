package com.example.myapplication.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.ChannelRepository
import com.example.myapplication.R

class FilterDialogFragment(private val onApply: (Map<String, List<String>>) -> Unit) : DialogFragment() {

    private val filterGroups = listOf(
        FilterGroup("satellite", "الأقمار 🛰️", emptyList()),
        FilterGroup("category", "التصنيفات 📺", emptyList()),
        FilterGroup("encryption", "التشفير 🔐", listOf("FTA", "Encrypted"))
    )
    private var selectedGroupIndex = 0
    private val selectedFilters = mutableMapOf<String, MutableList<String>>()
    private var rvDetails: RecyclerView? = null
    private var btnApply: Button? = null

    data class FilterGroup(val key: String, val label: String, val staticItems: List<String>)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.dialog_filter, container, false)

        val rvCats = view.findViewById<RecyclerView>(R.id.rvFilterCategories)
        rvDetails = view.findViewById(R.id.rvFilterDetails)
        btnApply = view.findViewById(R.id.btnApplyFilter)
        val btnClose = view.findViewById<Button>(R.id.btnCloseFilter)

        val repo = ChannelRepository()

        rvCats.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rvCats.adapter = GroupTabAdapter(filterGroups.map { it.label }, selectedGroupIndex) { idx ->
            selectedGroupIndex = idx
            updateDetails(repo)
        }

        updateDetails(repo)

        btnApply?.setOnClickListener {
            onApply(selectedFilters)
            dismiss()
        }
        btnApply?.isEnabled = false
        btnApply?.alpha = 0.5f

        btnClose.setOnClickListener { dismiss() }
        return view
    }

    private fun updateDetails(repo: ChannelRepository) {
        val group = filterGroups[selectedGroupIndex]
        val items = when (group.key) {
            "satellite" -> repo.getSatellites(requireContext())
            "category" -> repo.getCategories(requireContext())
            else -> group.staticItems
        }
        val selected = selectedFilters[group.key] ?: mutableListOf()
        
        // Show as a grid for better selection (Horizontal feel)
        rvDetails?.layoutManager = GridLayoutManager(context, 2)
        rvDetails?.adapter = FilterItemAdapter(items, selected) { item, isSelected ->
            val list = selectedFilters[group.key] ?: mutableListOf()
            if (isSelected) list.add(item) else list.remove(item)
            selectedFilters[group.key] = list
            val hasAny = selectedFilters.values.any { it.isNotEmpty() }
            btnApply?.isEnabled = hasAny
            btnApply?.alpha = if (hasAny) 1.0f else 0.5f
        }
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    }

    inner class GroupTabAdapter(
        val list: List<String>,
        var selected: Int,
        val onClick: (Int) -> Unit
    ) : RecyclerView.Adapter<GroupTabAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val txt = v as TextView
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(TextView(p.context).apply {
            layoutParams = ViewGroup.LayoutParams(-2, -2)
            setPadding(40, 24, 40, 24)
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        override fun onBindViewHolder(h: VH, p: Int) {
            h.txt.text = list[p]
            if (p == selected) {
                h.txt.setBackgroundResource(R.drawable.bg_search) // Rounded pill
                h.txt.setTextColor(android.graphics.Color.BLACK)
            } else {
                h.txt.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                h.txt.setTextColor(android.graphics.Color.WHITE)
            }
            h.txt.setOnClickListener {
                selected = p
                notifyDataSetChanged()
                onClick(p)
            }
        }
        override fun getItemCount() = list.size
    }

    inner class FilterItemAdapter(
        val list: List<String>,
        val selected: MutableList<String>,
        val onCheck: (String, Boolean) -> Unit
    ) : RecyclerView.Adapter<FilterItemAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val txt = v as TextView
        }
        override fun onCreateViewHolder(p: ViewGroup, t: Int) = VH(TextView(p.context).apply {
            val lp = GridLayoutManager.LayoutParams(-1, -2)
            lp.setMargins(8, 8, 8, 8)
            layoutParams = lp
            setPadding(16, 40, 16, 40)
            textSize = 14f
            gravity = android.view.Gravity.CENTER
            setBackgroundResource(R.drawable.bg_search_dark)
        })
        override fun onBindViewHolder(h: VH, p: Int) {
            val item = list[p]
            val isChecked = selected.contains(item)
            h.txt.text = if (isChecked) "✓ $item" else item
            if (isChecked) {
                h.txt.setBackgroundResource(R.drawable.bg_search) // Highlight selected
                h.txt.setTextColor(android.graphics.Color.BLACK)
            } else {
                h.txt.setBackgroundResource(R.drawable.bg_search_dark)
                h.txt.setTextColor(android.graphics.Color.WHITE)
            }
            h.txt.setOnClickListener {
                val isNowSelected = !selected.contains(item)
                if (isNowSelected) selected.add(item) else selected.remove(item)
                onCheck(item, isNowSelected)
                notifyItemChanged(p)
            }
        }
        override fun getItemCount() = list.size
    }
}
