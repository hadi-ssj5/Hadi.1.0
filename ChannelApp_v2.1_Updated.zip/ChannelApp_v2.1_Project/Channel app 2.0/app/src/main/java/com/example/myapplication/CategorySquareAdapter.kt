package com.example.myapplication

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class CategorySquareAdapter(private val items: List<String>, private val onClick: (String) -> Unit) :
    RecyclerView.Adapter<CategorySquareAdapter.ViewHolder>() {

    // ALL colors are vivid - no gray, no black, no dark neutrals
    private val colorMap = mapOf(
        "Nile" to "#E64A19",
        "Astra" to "#6A1B9A",
        "Arabsat" to "#1565C0",
        "Hotbird" to "#AD1457",
        "Eutelsat" to "#E65100",
        "Galaxy" to "#2E7D32",
        "Badr" to "#7B1FA2",
        "Yahsat" to "#00695C",
        "Turksat" to "#283593",
        "Cartoon" to "#1565C0",
        "Kids" to "#AD1457",
        "Kid" to "#AD1457",
        "Family" to "#6A1B9A",
        "News" to "#E64A19",
        "Doc" to "#6D4C41",
        "Sports" to "#1B5E20",
        "Movie" to "#880E4F",
        "Series" to "#01579B",
        "Reality" to "#2E7D32",
        "Music" to "#4527A0",
        "Religion" to "#BF360C",
        "Religious" to "#BF360C",
        "Educational" to "#00695C",
        "Free" to "#1565C0",
        "HD" to "#4527A0",
        "Variety" to "#558B2F",
        "Es'hail" to "#00838F",
        "General" to "#37474F"
    )

    // Fallback color palette - no gray, no black
    private val fallbackColors = listOf(
        "#E64A19", "#6A1B9A", "#1565C0", "#AD1457",
        "#E65100", "#2E7D32", "#00838F", "#6D4C41",
        "#283593", "#00695C", "#558B2F", "#7B1FA2",
        "#BF360C", "#4527A0", "#01579B", "#1B5E20"
    )

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.tvCategorySquareName)
        val card: MaterialCardView = view.findViewById(R.id.categoryCard)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_category_square, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.name.text = item

        var colorStr: String? = null
        for ((key, value) in colorMap) {
            if (item.contains(key, ignoreCase = true)) {
                colorStr = value
                break
            }
        }

        // If no match found, use fallback palette (cycling through vivid colors)
        if (colorStr == null) {
            colorStr = fallbackColors[position % fallbackColors.size]
        }

        holder.card.setCardBackgroundColor(Color.parseColor(colorStr))
        holder.card.strokeWidth = 0
        holder.name.setTextColor(Color.WHITE)
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount() = items.size
}
