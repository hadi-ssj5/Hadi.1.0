package com.example.myapplication.network

import com.example.myapplication.model.Channel
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    // هذا مثال لنقطة نهاية (Endpoint) لجلب الترددات
    // بما أن LyngSat لا يوفر API رسمي، عادة ما يتم الربط بخادم وسيط (Backend)
    @GET("channels.json")
    fun getChannels(): Call<List<Channel>>
}
