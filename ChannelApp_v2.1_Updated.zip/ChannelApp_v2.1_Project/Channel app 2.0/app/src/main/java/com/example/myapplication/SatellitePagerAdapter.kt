package com.example.myapplication

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.model.Channel

class SatellitePagerAdapter(
    private val satellites: List<Channel>
) : RecyclerView.Adapter<SatellitePagerAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: View) : RecyclerView.ViewHolder(binding)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_satellite_card, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = satellites[position]
        val view = holder.binding

        // Satellite header - format nicely
        val satHeader = formatSatelliteName(item.satellite)
        view.findViewById<TextView>(R.id.tvSatelliteHeader).text = satHeader

        // Frequency
        view.findViewById<TextView>(R.id.tvFrequency).text = item.frequency

        // Polarization  
        val polFull = when (item.polarization.uppercase()) {
            "H" -> "H (أفقي)"
            "V" -> "V (عمودي)"
            else -> item.polarization
        }
        view.findViewById<TextView>(R.id.tvPolarization).text = polFull

        // Symbol Rate
        view.findViewById<TextView>(R.id.tvSymbolRate).text = item.symbolRate

        // Encryption
        val isEnc = item.encryption.contains("Enc", ignoreCase = true)
        view.findViewById<TextView>(R.id.tvEncryption).text = if (isEnc) "مشفر 🔐" else "مفتوح (FTA) ✅"

        // Quality badge
        val qualityView = view.findViewById<TextView>(R.id.tvQualityBadge)
        val quality = detectQuality(item)
        qualityView.text = quality
        qualityView.backgroundTintList = android.content.res.ColorStateList.valueOf(
            when (quality) {
                "HD" -> Color.parseColor("#1565C0")
                "FHD" -> Color.parseColor("#6A1B9A")
                "4K" -> Color.parseColor("#004D40")
                else -> Color.parseColor("#37474F") // SD
            }
        )

        // Encryption badge
        val encView = view.findViewById<TextView>(R.id.tvEncryptionBadge)
        encView.text = if (isEnc) "Encrypted" else "FTA"
        encView.backgroundTintList = android.content.res.ColorStateList.valueOf(
            if (isEnc) Color.parseColor("#B71C1C") else Color.parseColor("#2E7D32")
        )
    }

    private fun formatSatelliteName(sat: String): String {
        // "Nilesat 7.0°W" -> "NILESAT 7.0°W"
        return sat.uppercase()
    }

    private fun detectQuality(ch: Channel): String {
        val combined = "${ch.frequency} ${ch.symbolRate} ${ch.name}".uppercase()
        return when {
            combined.contains("4K") || combined.contains("UHD") -> "4K"
            combined.contains("FHD") || combined.contains("1080") -> "FHD"
            combined.contains("HD") -> "HD"
            else -> "SD"
        }
    }

    override fun getItemCount() = satellites.size
}
