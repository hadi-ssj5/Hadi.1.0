package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.request.CachePolicy
import com.example.myapplication.model.Channel
import kotlin.random.Random

class HorizontalChannelAdapter(
    private val channels: List<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<HorizontalChannelAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.channelHorizImg)
        val name: TextView = view.findViewById(R.id.channelHorizName)
        val progress: ProgressBar = view.findViewById(R.id.channelHorizProgress)
        val percent: TextView = view.findViewById(R.id.channelHorizPercent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_channel_horizontal, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val channel = channels[position]
        holder.name.text = channel.name
        
        // Simulated popularity percentage
        val pct = Random.nextInt(10, 95)
        holder.progress.progress = pct
        holder.percent.text = "$pct%"

        if (channel.imageUrl.isNotEmpty()) {
            holder.img.load(channel.imageUrl) {
                crossfade(true)
                memoryCachePolicy(CachePolicy.ENABLED)
                diskCachePolicy(CachePolicy.ENABLED)
                placeholder(R.drawable.ic_tv_placeholder)
                error(R.drawable.ic_tv_placeholder)
            }
        } else {
            holder.img.setImageResource(R.drawable.ic_tv_placeholder)
        }

        holder.itemView.setOnClickListener { onClick(channel) }
    }

    override fun getItemCount() = channels.size
}
