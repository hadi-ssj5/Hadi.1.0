package com.example.myapplication.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.*
import com.example.myapplication.model.Channel

class HomeFragment : Fragment() {

    private lateinit var contentLayout: LinearLayout
    private val repository = ChannelRepository()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)
        contentLayout = view.findViewById(R.id.home_content_layout)

        view.findViewById<Button>(R.id.btnShowAll).setOnClickListener {
            navigateToResults("كافة القنوات", "all")
        }

        setupDynamicRows()
        setupFixedGrid(view)

        return view
    }

    private fun navigateToResults(title: String, type: String) {
        val fragment = ResultsFragment()
        val bundle = Bundle()
        bundle.putString("title", title)
        bundle.putString("type", type)
        fragment.arguments = bundle
        parentFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun setupDynamicRows() {
        val allChannels = repository.getLocalChannels(requireContext())
        val catsToShow = listOf("Kids" to "Cartoons", "Movies" to "Movies", "Sports" to "Sports",
                                "News" to "News", "Religious" to "Religious", "Series" to "Series")

        contentLayout.removeAllViews()
        for ((catKey, catDisplay) in catsToShow) {
            val channels = allChannels.filter { it.category.equals(catKey, ignoreCase = true) }
            if (channels.isNotEmpty()) {
                addCategoryRow(catKey, channels)
            }
        }
    }

    private fun addCategoryRow(category: String, channels: List<Channel>) {
        val rowView = LayoutInflater.from(requireContext()).inflate(R.layout.item_category_row, contentLayout, false)
        val tvName = rowView.findViewById<TextView>(R.id.tvCategoryName)
        val btnSeeAll = rowView.findViewById<Button>(R.id.btnSeeAllCategory)
        val rvChannels = rowView.findViewById<RecyclerView>(R.id.rvCategoryChannels)

        val translatedName = repository.mapEnToAr(category)
        tvName.text = translatedName
        rvChannels.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        rvChannels.adapter = HorizontalChannelAdapter(channels.shuffled().take(10)) { channel ->
            ChannelAdapter.showDetailDialog(requireContext(), channel)
        }

        btnSeeAll.setOnClickListener { navigateToResults(category, "category") }
        contentLayout.addView(rowView)
    }

    private fun setupFixedGrid(view: View) {
        val rv = view.findViewById<RecyclerView>(R.id.rvHomeSatellites)
        // Satellites row
        val satellites = listOf("Nile", "Badr", "Arabsat", "Astra",
                                "Hotbird", "Galaxy 19", "Es'hail", "Eutelsat")
        // Categories row  
        val categories = listOf("Free", "Movie", "Sports", "News",
                                "Kid", "Doc", "Series", "HD",
                                "Religious", "Variety", "Music", "Educational")
        val items = satellites + categories
        rv.layoutManager = GridLayoutManager(requireContext(), 4)
        rv.adapter = CategorySquareAdapter(items) { item ->
            val type = if (satellites.contains(item)) "satellite" else "category"
            navigateToResults(item, type)
        }
    }

    private fun navigateToSearch(query: String) {
        val searchFragment = SearchFragment()
        val bundle = Bundle()
        bundle.putString("category", query)
        searchFragment.arguments = bundle
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, searchFragment)
            .addToBackStack(null)
            .commit()
    }
}
