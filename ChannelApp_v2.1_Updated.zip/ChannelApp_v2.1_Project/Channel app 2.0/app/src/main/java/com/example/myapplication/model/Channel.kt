package com.example.myapplication.model

data class Channel(
    val name: String,
    val frequency: String,
    val satellite: String,
    val polarization: String,
    val symbolRate: String,
    val category: String,       // English category
    val categoryAr: String = "",  // Arabic category
    val encryption: String = "FTA",
    val imageUrl: String = "",
    var isFavorite: Boolean = false
)
