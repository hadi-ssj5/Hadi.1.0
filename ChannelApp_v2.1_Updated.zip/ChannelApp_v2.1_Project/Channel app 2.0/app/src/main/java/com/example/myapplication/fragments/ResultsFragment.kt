package com.example.myapplication.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.ChannelAdapter
import com.example.myapplication.ChannelRepository
import com.example.myapplication.R
import com.example.myapplication.model.Channel

class ResultsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_results, container, false)

        val title = arguments?.getString("title") ?: "النتائج"
        val filterType = arguments?.getString("type") ?: ""
        val categoryFilter = arguments?.getString("category")
        val satelliteFilter = arguments?.getString("satellite")
        
        val tvTitle = view.findViewById<TextView>(R.id.tvResultsTitle)
        val btnBack = view.findViewById<ImageButton>(R.id.btnBack)
        val rv = view.findViewById<RecyclerView>(R.id.rvResultsList)

        tvTitle.text = title
        btnBack.setOnClickListener { 
            hideKeyboard()
            parentFragmentManager.popBackStack() 
        }

        hideKeyboard()

        val repo = ChannelRepository()
        val all = repo.getLocalChannels(requireContext())
        
        var filtered = when(filterType) {
            "category" -> all.filter { it.category.equals(title, true) || it.categoryAr.contains(title) }
            "satellite" -> all.filter { it.satellite.contains(title, true) }
            else -> all
        }

        // Apply extra specific filters if passed
        categoryFilter?.let { cat ->
            filtered = filtered.filter { it.category.equals(cat, true) || it.categoryAr.contains(cat) }
        }
        satelliteFilter?.let { sat ->
            filtered = filtered.filter { it.satellite.contains(sat, true) }
        }

        rv.layoutManager = GridLayoutManager(requireContext(), 3)
        rv.adapter = ChannelAdapter(filtered)

        return view
    }

    private fun hideKeyboard() {
        val imm = requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        imm.hideSoftInputFromWindow(view?.windowToken, 0)
    }
}
