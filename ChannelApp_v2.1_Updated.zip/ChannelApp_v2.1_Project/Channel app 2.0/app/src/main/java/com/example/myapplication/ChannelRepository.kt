package com.example.myapplication

import android.content.Context
import com.example.myapplication.model.Channel

class ChannelRepository {

    companion object {
        // High-quality logo URLs that actually work
        val logoMap = mapOf(
            "MBC 1" to "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/MBC1_logo.png/200px-MBC1_logo.png",
            "MBC 2" to "https://upload.wikimedia.org/wikipedia/ar/thumb/0/0e/MBC2_Logo.png/200px-MBC2_Logo.png",
            "MBC 3" to "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/MBC3_logo.svg/200px-MBC3_logo.svg.png",
            "MBC 4" to "https://upload.wikimedia.org/wikipedia/ar/thumb/d/d4/MBC4_Logo.png/200px-MBC4_Logo.png",
            "MBC Action" to "https://upload.wikimedia.org/wikipedia/ar/thumb/8/82/MBC_Action_logo.png/200px-MBC_Action_logo.png",
            "MBC Drama" to "https://upload.wikimedia.org/wikipedia/ar/thumb/3/36/MBC_Drama_logo.png/200px-MBC_Drama_logo.png",
            "MBC Masr" to "https://upload.wikimedia.org/wikipedia/ar/thumb/6/61/MBC_Masr_logo.png/200px-MBC_Masr_logo.png",
            "MBC Max" to "https://upload.wikimedia.org/wikipedia/ar/thumb/e/e5/MBC_Max_Logo.png/200px-MBC_Max_Logo.png",
            "Al Jazeera" to "https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Aljazeera_eng_logo.png/200px-Aljazeera_eng_logo.png",
            "Al Arabiya" to "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/Alarabiya_new_logo.svg/200px-Alarabiya_new_logo.svg.png",
            "Rotana Cinema" to "https://upload.wikimedia.org/wikipedia/ar/thumb/8/83/Rotana_Cinema.jpg/200px-Rotana_Cinema.jpg",
            "Rotana Khalijia" to "https://upload.wikimedia.org/wikipedia/ar/thumb/d/de/Rotana_Khalijia.jpg/200px-Rotana_Khalijia.jpg",
            "Rotana Classic" to "https://upload.wikimedia.org/wikipedia/ar/thumb/9/90/Rotana_Classic.jpg/200px-Rotana_Classic.jpg",
            "Dubai TV" to "https://upload.wikimedia.org/wikipedia/ar/thumb/5/5e/Dubai_TV_Logo.png/200px-Dubai_TV_Logo.png",
            "Toyor Al Janah" to "https://upload.wikimedia.org/wikipedia/ar/thumb/8/89/Toyor_Aljanah_logo.png/200px-Toyor_Aljanah_logo.png",
            "Spacetoon" to "https://upload.wikimedia.org/wikipedia/en/thumb/5/58/Spacetoon_logo.png/200px-Spacetoon_logo.png",
            "beIN Sports 1" to "https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/BeIN_Sports_logo.svg/200px-BeIN_Sports_logo.svg.png",
            "BBC Arabic" to "https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/BBC_News_2019.svg/200px-BBC_News_2019.svg.png",
            "Discovery" to "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Discovery_logo_2019.svg/200px-Discovery_logo_2019.svg.png",
            "National Geographic" to "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/National_Geographic_logo.svg/200px-National_Geographic_logo.svg.png",
            "Disney Channel" to "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Disney_Channel_logo.svg/200px-Disney_Channel_logo.svg.png",
            "Nickelodeon" to "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Nickelodeon_logo.svg/200px-Nickelodeon_logo.svg.png",
            "Russia Today" to "https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/RT_logo.svg/200px-RT_logo.svg.png",
            "TRT Arabic" to "https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/TRT_Logo.svg/200px-TRT_Logo.svg.png",
            "Alkass" to "https://upload.wikimedia.org/wikipedia/ar/thumb/4/48/Alkass_FC_logo.png/200px-Alkass_FC_logo.png",
            "Al Nahar" to "https://upload.wikimedia.org/wikipedia/ar/thumb/9/94/Al_Nahar_logo.png/200px-Al_Nahar_logo.png",
            "DMC" to "https://upload.wikimedia.org/wikipedia/ar/thumb/9/96/DMC_TV_logo.png/200px-DMC_TV_logo.png",
            "Sky News Arabia" to "https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Sky_News_Arabia.svg/200px-Sky_News_Arabia.svg.png",
            "CNN Arabic" to "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/CNN_logo.svg/200px-CNN_logo.svg.png",
            "Al Hadath" to "https://upload.wikimedia.org/wikipedia/commons/thumb/6/67/AlHadath.svg/200px-AlHadath.svg.png",
            "Saudi TV" to "https://upload.wikimedia.org/wikipedia/ar/thumb/8/87/Saudi_TV_logo.png/200px-Saudi_TV_logo.png",
            "beIN" to "https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/BeIN_Sports_logo.svg/200px-BeIN_Sports_logo.svg.png",
            "OSN" to "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/OSN_logo.svg/200px-OSN_logo.svg.png"
        )

        fun getLogoUrl(name: String): String {
            // Try exact match first
            logoMap[name]?.let { return it }
            // Try partial match
            for ((key, url) in logoMap) {
                if (name.contains(key, ignoreCase = true) || key.contains(name, ignoreCase = true)) return url
            }
            // Try keyword match
            val keywords = listOf("MBC","Jazeera","Arabiya","Hadath","Rotana","Saudi","Ekhbariya",
                "Dubai","Toyor","Spacetoon","beIN","BBC","Discovery","National","Disney",
                "Nickelodeon","RT","TRT","Alkass","Nahar","DMC","CNN","Sky","OSN")
            for (kw in keywords) {
                if (name.contains(kw, ignoreCase = true)) {
                    logoMap.entries.firstOrNull { it.key.contains(kw, ignoreCase = true) }?.let { return it.value }
                }
            }
            // Generate avatar as fallback
            val displayName = name.take(3).uppercase()
            return "https://ui-avatars.com/api/?name=${android.net.Uri.encode(displayName)}&size=200&background=9866FF&color=fff&bold=true&length=2"
        }
    }

    private var cachedChannels: List<Channel>? = null

    fun getLocalChannels(context: Context): List<Channel> {
        if (cachedChannels != null) return cachedChannels!!
        val channels = mutableListOf<Channel>()
        var currentSatellite = "Nilesat 7.0°W"
        try {
            val inputStream = context.assets.open("channels.txt")
            inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val trimmed = line.trim()
                    if (trimmed.isEmpty()) return@forEach
                    if (trimmed.startsWith(".") || trimmed.startsWith("**") || (trimmed.contains("°") && !trimmed.contains(":"))) {
                        val sat = trimmed.removePrefix(".").removePrefix("**").removeSuffix("**").trim()
                        if (sat.isNotEmpty()) currentSatellite = sat
                    } else if (trimmed.contains(":")) {
                        try {
                            val name = trimmed.substringBefore(":").trim().removePrefix("- ")
                            val rest = trimmed.substringAfter(":").trim()
                            val parts = rest.split("-").map { it.trim() }
                            if (parts.size >= 2) {
                                val freqInfo = parts[0].split(" ")
                                val catAr = parts[1]
                                val enc = parts.getOrNull(2) ?: "FTA"
                                val freq = freqInfo.getOrNull(0) ?: ""
                                val pol = freqInfo.getOrNull(1) ?: ""
                                val sr = freqInfo.getOrNull(2) ?: ""
                                channels.add(Channel(
                                    name, freq, currentSatellite, pol, sr,
                                    mapCategoryToEn(catAr), catAr, enc, getLogoUrl(name)
                                ))
                            }
                        } catch (e: Exception) {}
                    }
                }
            }
        } catch (e: Exception) {}
        cachedChannels = channels.distinctBy { it.name + it.frequency + it.satellite }.sortedBy { it.name }
        return cachedChannels!!
    }

    private fun mapCategoryToEn(arCat: String): String = when {
        arCat.contains("أخبار") -> "News"
        arCat.contains("رياضة") -> "Sports"
        arCat.contains("أفلام") -> "Movies"
        arCat.contains("كرتون") || arCat.contains("أطفال") -> "Kids"
        arCat.contains("ديني") -> "Religious"
        arCat.contains("دراما") -> "Series"
        arCat.contains("وثائقي") -> "Documentary"
        else -> "General"
    }

    fun mapEnToAr(enCat: String): String = when (enCat) {
        "News" -> "أخبار"
        "Sports" -> "رياضة"
        "Movies" -> "أفلام"
        "Kids" -> "كرتون"
        "Religious" -> "ديني"
        "Series" -> "دراما"
        "Documentary" -> "وثائقي"
        else -> "عامة"
    }

    fun getCategories(context: Context): List<String> = getLocalChannels(context).map { it.category }.distinct().sorted()
    fun getSatellites(context: Context): List<String> = getLocalChannels(context).map { it.satellite }.distinct().sorted()
}
